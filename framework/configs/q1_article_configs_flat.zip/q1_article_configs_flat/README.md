# Flat Q1 article configs

Все JSON сложены в одну папку q1_article_all_configs для удобного batch-запуска.
При этом out_dir в каждом конфиге указывает только на серию: models/q1_article/<series>.
Это согласуется с sim_framework: итоговый путь будет models/q1_article/<series>/<run_id>, потому что Simulator сам дописывает run_id как последнюю папку.
