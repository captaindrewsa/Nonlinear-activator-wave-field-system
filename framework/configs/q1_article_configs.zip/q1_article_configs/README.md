# Q1 Article configs

Серии внутри models/q1_article:
- reference_pair: эталонная пара, 10 seed
- pair_distance_scan: скан по расстоянию для пары
- topology_check: line3, square4, ring6
- long_graph_runs: длинные прогоны для анализа перестроек графа и фазовой синхронизации

Все конфиги используют out_dir формата models/q1_article/<series>/<tag>.
Якорь по умолчанию: anchor_gamma.
